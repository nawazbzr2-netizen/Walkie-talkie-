# PhoneLink

Phone-to-phone calls, video calls, chat, voice messages and file transfer — **without phone numbers** —
over Wi-Fi, mobile hotspot, Bluetooth or the internet.

| Feature | Wi-Fi / Hotspot | Bluetooth | Internet |
|---|---|---|---|
| Device list with IP address, tap to connect | ✅ (mDNS + subnet scan + manual IP) | ✅ paired phones | ✅ by ID code |
| Several phones at once | ✅ ("Connect all") | ✅ | ✅ |
| Voice call, no time limit | ✅ WebRTC | ✅ audio stream | ✅ WebRTC |
| Video call | ✅ | ❌ (Bluetooth is too slow) | ✅ |
| Text messages | ✅ | ✅ | ✅ |
| Voice messages (hold mic) | ✅ | ✅ | ✅ |
| Files of any type | ✅ fast | ✅ slow | ✅ via server (small files) |
| Incoming call ringtone | ✅ | ✅ | ✅ |
| Auto-reconnect after drop | ✅ | ✅ | ✅ |
| Call-stuck protection (30s timeout + full cleanup) | ✅ | ✅ | ✅ |

* `app/` – Android app (Kotlin, Jetpack Compose, WebRTC)
* `server/` – tiny Node.js signalling/relay server (only needed for the **Internet** tab)
* `docs/GUIDE_UR.md` – **step-by-step guide in Urdu** (اردو گائیڈ)
* `.github/workflows/android.yml` – GitHub builds the APK for you on every push

Build: push to GitHub → *Actions* → *Build APK* → download artifact `PhoneLink-debug-apk`.
Or open the folder in Android Studio (Ladybug or newer) and press Run.

> Permissions: mic / camera / Bluetooth are requested only when the feature needs them.
> If the user denies a permission, that feature simply does not work (Google policy compliant).
> Remote camera / mic / system-audio **without the other phone granting permission is impossible** on Android.
