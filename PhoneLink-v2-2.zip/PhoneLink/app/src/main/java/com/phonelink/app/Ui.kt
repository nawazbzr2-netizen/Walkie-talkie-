package com.phonelink.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.io.File

typealias PermRunner = (List<String>, () -> Unit) -> Unit

// =====================================================================
//  Root
// =====================================================================

@Composable
fun PhoneLinkApp() {
    val ctx = LocalContext.current
    val call by Calls.ui.collectAsState()
    var openPeer by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val p = pending
        pending = null
        if (p != null) {
            if (res.values.all { it }) p() else Hub.toast("Permission is needed for this feature")
        }
        Hub.startBt()
        Hub.refreshBt()
    }

    val withPerms: PermRunner = { perms, action ->
        val missing = perms.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) action() else {
            pending = action
            launcher.launch(missing.toTypedArray())
        }
    }

    LaunchedEffect(Unit) {
        val first = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) first.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) {
            first.add(Manifest.permission.BLUETOOTH_CONNECT)
            first.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        val missing = first.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) launcher.launch(missing.toTypedArray())
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        val peer = openPeer
        when {
            call.phase != Phase.IDLE -> CallScreen(call, withPerms)
            peer != null -> ChatScreen(peer, { openPeer = null }, withPerms)
            else -> HomeScreen({ openPeer = it }, withPerms)
        }
    }
}

// =====================================================================
//  Home: connected phones + Wi-Fi / Bluetooth / Internet tabs
// =====================================================================

@Composable
fun HomeScreen(onOpen: (String) -> Unit, withPerms: PermRunner) {
    val ctx = LocalContext.current
    val peers by Hub.peers.collectAsState()
    val disc by Hub.discovered.collectAsState()
    val bt by Hub.btDevices.collectAsState()
    val ips by Hub.myIps.collectAsState()
    val scanning by Hub.scanning.collectAsState()
    val netStatus by Hub.netStatus.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var manualIp by remember { mutableStateOf("") }
    var friendId by remember { mutableStateOf("") }
    val btPerms = if (Build.VERSION.SDK_INT >= 31)
        listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN) else emptyList()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("PhoneLink", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(
                    Hub.myName + if (ips.isEmpty()) "  •  no Wi-Fi" else "  •  " + ips.joinToString(", "),
                    fontSize = 12.sp, color = Color.Gray
                )
            }
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings") }
        }

        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            item { Text("Connected (${peers.size})", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 8.dp)) }
            if (peers.isEmpty()) item { Text("Nobody yet. Use the tabs below to connect.", color = Color.Gray, fontSize = 13.sp) }
            items(peers, key = { it.key }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onOpen(p.key) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(kindIcon(p.kind), null)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Medium)
                            Text(kindLabel(p.kind) + "  •  " + p.address, fontSize = 12.sp, color = Color.Gray)
                        }
                        IconButton(onClick = { Hub.disconnect(p.key) }) { Icon(Icons.Default.Close, "Disconnect") }
                    }
                }
            }

            item {
                TabRow(selectedTabIndex = tab, modifier = Modifier.padding(top = 12.dp)) {
                    listOf("Wi-Fi / Hotspot", "Bluetooth", "Internet").forEachIndexed { i, t ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, maxLines = 1, fontSize = 13.sp) })
                    }
                }
            }

            if (tab == 0) {
                item {
                    Text(
                        "Phones with PhoneLink on the same Wi-Fi or hotspot appear here with their IP address. Tap one to connect.",
                        fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { Hub.refreshIps(); Hub.scanNetwork() }) { Text(if (scanning) "Scanning…" else "Scan network") }
                        Button(onClick = { Hub.connectAll() }, enabled = disc.isNotEmpty()) { Text("Connect all") }
                    }
                    OutlinedButton(onClick = { Hub.connectGateway() }, modifier = Modifier.padding(top = 4.dp)) {
                        Text("Connect to hotspot owner")
                    }
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            manualIp, { manualIp = it }, Modifier.weight(1f), singleLine = true,
                            label = { Text("IP address, e.g. 192.168.43.1") }
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { Hub.connectWifi(manualIp); manualIp = "" }, enabled = manualIp.isNotBlank()) { Text("Connect") }
                    }
                }
                items(disc, key = { it.host }) { d ->
                    val connected = peers.any { it.key == "WIFI:${d.host}" }
                    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable(enabled = !connected) { Hub.connectWifi(d.host, d.port) }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, null)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.name, fontWeight = FontWeight.Medium)
                                Text("IP: ${d.host}", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text(if (connected) "Connected" else "Tap to connect", fontSize = 12.sp)
                        }
                    }
                }
            }

            if (tab == 1) {
                item {
                    Text(
                        "1) Pair the phones in Android's Bluetooth settings. 2) Open PhoneLink on both. 3) Tap the paired phone below.",
                        fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { withPerms(btPerms) { Hub.startBt(); Hub.refreshBt() } }) { Text("Refresh paired phones") }
                        OutlinedButton(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }) { Text("Bluetooth settings") }
                    }
                }
                items(bt, key = { it.mac }) { d ->
                    val connected = peers.any { it.key == "BT:${d.mac}" }
                    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable(enabled = !connected) {
                        withPerms(btPerms) { Hub.connectBt(d.mac) }
                    }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bluetooth, null)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.name, fontWeight = FontWeight.Medium)
                                Text(d.mac, fontSize = 12.sp, color = Color.Gray)
                            }
                            Text(if (connected) "Connected" else "Tap to connect", fontSize = 12.sp)
                        }
                    }
                }
            }

            if (tab == 2) {
                item {
                    Column(Modifier.padding(vertical = 8.dp)) {
                        Text(
                            "Call, message and send files over mobile data or any Wi-Fi, with no phone number. " +
                                "Give your friend this ID code:", fontSize = 12.sp, color = Color.Gray
                        )
                        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(Hub.myId.chunked(5).joinToString("-"), fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("PhoneLink ID", Hub.myId))
                                Hub.toast("ID copied")
                            }) { Text("Copy") }
                        }
                        Text("Server: $netStatus", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                            Button(onClick = { Hub.connectServer() }) { Text("Go online") }
                            OutlinedButton(onClick = { Hub.disconnectServer() }) { Text("Go offline") }
                        }
                        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                friendId, { friendId = it }, Modifier.weight(1f), singleLine = true,
                                label = { Text("Friend's ID code") }
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { Hub.connectNet(friendId); friendId = "" }, enabled = friendId.isNotBlank()) { Text("Connect") }
                        }
                        Text(
                            "Set your server address in Settings (⚙). See docs/GUIDE_UR.md (section 5) for how to host it for free.",
                            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }

    if (showSettings) SettingsDialog { showSettings = false }
}

@Composable
fun SettingsDialog(onClose: () -> Unit) {
    var name by remember { mutableStateOf(Hub.myName) }
    var server by remember { mutableStateOf(Hub.serverUrl) }
    var turnUrl by remember { mutableStateOf(Hub.prefs.getString("turn_url", "") ?: "") }
    var turnUser by remember { mutableStateOf(Hub.prefs.getString("turn_user", "") ?: "") }
    var turnPass by remember { mutableStateOf(Hub.prefs.getString("turn_pass", "") ?: "") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Settings") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("This phone's name") })
                OutlinedTextField(server, { server = it }, singleLine = true, label = { Text("Server (wss://…)") })
                OutlinedTextField(turnUrl, { turnUrl = it }, singleLine = true, label = { Text("TURN url (optional)") })
                OutlinedTextField(turnUser, { turnUser = it }, singleLine = true, label = { Text("TURN user") })
                OutlinedTextField(turnPass, { turnPass = it }, singleLine = true, label = { Text("TURN password") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val changed = server.trim() != Hub.serverUrl
                Hub.myName = name
                Hub.serverUrl = server
                Hub.prefs.edit().putString("turn_url", turnUrl.trim())
                    .putString("turn_user", turnUser.trim()).putString("turn_pass", turnPass).apply()
                if (changed && server.isNotBlank()) Hub.connectServer()
                onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

private fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.WIFI -> Icons.Default.Wifi
    Kind.BT -> Icons.Default.Bluetooth
    Kind.NET -> Icons.Default.Language
}

private fun kindLabel(k: Kind) = when (k) {
    Kind.WIFI -> "Wi-Fi / hotspot"
    Kind.BT -> "Bluetooth"
    Kind.NET -> "Internet"
}

// =====================================================================
//  Chat
// =====================================================================

class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    fun start(): Boolean = try {
        val f = File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioEncodingBitRate(48000)
        r.setAudioSamplingRate(24000)
        r.setOutputFile(f.absolutePath)
        r.prepare()
        r.start()
        rec = r
        file = f
        true
    } catch (e: Exception) {
        false
    }

    fun stop(): File? {
        val r = rec ?: return null
        rec = null
        return try {
            r.stop()
            r.release()
            file
        } catch (e: Exception) {      // recording was too short
            try { r.release() } catch (_: Exception) {}
            null
        }
    }
}

@Composable
fun ChatScreen(peerKey: String, onBack: () -> Unit, withPerms: PermRunner) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val all by Hub.messages.collectAsState()
    val peers by Hub.peers.collectAsState()
    val peer = peers.firstOrNull { it.key == peerKey }
    val msgs = remember(all, peerKey) { all.filter { it.peerKey == peerKey } }
    var text by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    val recorder = remember { VoiceRecorder(ctx) }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) Hub.sendFile(peerKey, uri)
    }
    val connected = peer != null
    val isBt = peer?.kind == Kind.BT

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text(peer?.name ?: Hub.peerName(peerKey), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    if (peer == null) "Disconnected (auto-reconnect…)" else kindLabel(peer.kind) + "  •  connected",
                    fontSize = 12.sp, color = if (peer == null) Color(0xFFFF9800) else Color(0xFF4CAF50)
                )
            }
        }

        // ---- Action bar: Audio / Video / Voice-msg / File ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ActionChip(
                icon = Icons.Default.Call, label = "آڈیو کال", enabled = connected,
                onClick = { withPerms(listOf(Manifest.permission.RECORD_AUDIO)) { Calls.start(peerKey, false) } }
            )
            ActionChip(
                icon = Icons.Default.Videocam, label = "ویڈیو کال", enabled = connected && !isBt,
                onClick = {
                    withPerms(listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)) {
                        Calls.start(peerKey, true)
                    }
                }
            )
            ActionChip(
                icon = Icons.Default.AttachFile, label = "فائل", enabled = connected,
                onClick = { picker.launch("*/*") }
            )
            ActionChip(
                icon = Icons.Default.Mic, label = "وائس", enabled = connected,
                onClick = {
                    // short-tap opens mic permission; hold-to-record is in the bottom bar
                    withPerms(listOf(Manifest.permission.RECORD_AUDIO)) {
                        Hub.toast("نیچے مائیک بٹن دبا کر رکھیں")
                    }
                }
            )
        }

        LazyColumn(Modifier.weight(1f).padding(horizontal = 10.dp), state = listState) {
            items(msgs, key = { it.id }) { m -> MsgBubble(m) }
        }

        if (recording) Text("Recording… release to send", color = Color.Red, modifier = Modifier.padding(start = 16.dp))

        Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(enabled = connected, onClick = { picker.launch("*/*") }) { Icon(Icons.Default.AttachFile, "Send file") }
            OutlinedTextField(
                text, { text = it }, Modifier.weight(1f), maxLines = 4,
                placeholder = { Text("Message") }, enabled = connected
            )
            Spacer(Modifier.width(6.dp))
            if (text.isNotBlank()) {
                IconButton(enabled = connected, onClick = { Hub.sendText(peerKey, text); text = "" }) {
                    Icon(Icons.AutoMirrored.Filled.Send, "Send")
                }
            } else {
                Box(
                    Modifier.size(48.dp).clip(CircleShape)
                        .background(if (recording) Color.Red else MaterialTheme.colorScheme.primary)
                        .pointerInput(peerKey, connected) {
                            detectTapGestures(onPress = {
                                if (!connected) return@detectTapGestures
                                val hasMic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                                    PackageManager.PERMISSION_GRANTED
                                if (!hasMic) {
                                    withPerms(listOf(Manifest.permission.RECORD_AUDIO)) {}
                                } else if (recorder.start()) {
                                    recording = true
                                    tryAwaitRelease()
                                    recording = false
                                    recorder.stop()?.let { Hub.sendFile(peerKey, Uri.fromFile(it), voice = true) }
                                }
                            })
                        },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Mic, "Hold to record a voice message", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun ActionChip(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(enabled = enabled, onClick = onClick)) {
        Box(
            Modifier.size(52.dp).clip(CircleShape)
                .background(if (enabled) MaterialTheme.colorScheme.primaryContainer else Color.LightGray),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = if (enabled) MaterialTheme.colorScheme.onPrimaryContainer else Color.Gray)
        }
        Text(label, fontSize = 11.sp, color = if (enabled) Color.Unspecified else Color.Gray)
    }
}

@Composable
fun MsgBubble(m: Msg) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (m.mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(Modifier.padding(10.dp)) {
                when (m.kind) {
                    "text" -> Text(m.text)
                    "voice" -> VoiceBubble(m)
                    else -> FileBubble(m)
                }
            }
        }
    }
}

@Composable
fun VoiceBubble(m: Msg) {
    val ctx = LocalContext.current
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(Unit) { onDispose { try { player?.release() } catch (_: Exception) {} } }
    val ready = m.uri != null && (m.mine || m.status == "done")
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(enabled = ready, onClick = {
            try { player?.release() } catch (_: Exception) {}
            try {
                val p = MediaPlayer()
                p.setDataSource(ctx, Uri.parse(m.uri))
                p.prepare()
                p.setOnCompletionListener { it.release(); player = null }
                p.start()
                player = p
            } catch (e: Exception) {
                Hub.toast("Cannot play this voice message")
            }
        }) { Icon(Icons.Default.PlayArrow, "Play") }
        Column {
            Text("Voice message")
            Text(statusText(m), fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@Composable
fun FileBubble(m: Msg) {
    val ctx = LocalContext.current
    Text(m.text, fontWeight = FontWeight.Medium)
    Text((if (m.size >= 0) fmtSize(m.size) + "  •  " else "") + statusText(m), fontSize = 11.sp, color = Color.Gray)
    if ((m.status == "sending" || m.status == "receiving") && m.size > 0) {
        LinearProgressIndicator(
            progress = { (m.done.toFloat() / m.size).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
    }
    if (!m.mine && m.status == "offer") {
        Row {
            Button(onClick = { Hub.respondFile(m.peerKey, m.fid, true) }) { Text("Accept") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { Hub.respondFile(m.peerKey, m.fid, false) }) { Text("Decline") }
        }
    }
    if (!m.mine && m.status == "done" && m.uri != null) {
        TextButton(onClick = {
            try {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW).setData(Uri.parse(m.uri))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                Hub.toast("No app can open this file (saved in Downloads/PhoneLink)")
            }
        }) { Text("Open") }
    }
}

private fun statusText(m: Msg): String = when (m.status) {
    "waiting" -> "Waiting for the other phone to accept…"
    "offer" -> "Wants to send you this"
    "sending" -> "Sending… " + pct(m)
    "receiving" -> "Receiving… " + pct(m)
    "done" -> if (m.mine) "Sent" else if (m.kind == "voice") "Received" else "Saved in Downloads/PhoneLink"
    "declined" -> "Declined"
    "failed" -> "Failed"
    else -> ""
}

private fun pct(m: Msg) = if (m.size > 0) "${(m.done * 100 / m.size).coerceIn(0, 100)}%" else ""

private fun fmtSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    b < 1024L * 1024 * 1024 -> String.format("%.1f MB", b / 1048576.0)
    else -> String.format("%.2f GB", b / 1073741824.0)
}

// =====================================================================
//  Call screen
// =====================================================================

@Composable
fun CallScreen(call: CallUi, withPerms: PermRunner) {
    val remote by Calls.remoteVideo.collectAsState()
    val local by Calls.localVideo.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(call.phase) {
        while (call.phase == Phase.ACTIVE) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF101820))) {
        if (call.video && remote != null) VideoView(remote, Modifier.fillMaxSize())
        if (call.video && local != null) {
            VideoView(local, Modifier.align(Alignment.TopEnd).padding(16.dp).size(110.dp, 160.dp), mirror = true, overlay = true)
        }

        Column(Modifier.align(Alignment.TopCenter).padding(top = 72.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(call.peerName, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            val label = when (call.phase) {
                Phase.INCOMING -> if (call.video) "Incoming video call" else "Incoming call"
                Phase.OUTGOING -> "Calling…"
                Phase.CONNECTING -> "Connecting…"
                Phase.ACTIVE -> {
                    val s = ((now - call.startedAt) / 1000).coerceAtLeast(0)
                    String.format("%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                }
                Phase.IDLE -> ""
            }
            Text(label, color = Color(0xFFB0BEC5), fontSize = 16.sp)
            if (call.raw) Text("Bluetooth audio call", color = Color(0xFFB0BEC5), fontSize = 12.sp)
        }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            if (call.phase == Phase.INCOMING) {
                RoundBtn(Color(0xFF2E7D32), Icons.Default.Call) {
                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                    if (call.video) perms.add(Manifest.permission.CAMERA)
                    withPerms(perms) { Calls.accept() }
                }
                RoundBtn(Color(0xFFC62828), Icons.Default.CallEnd) { Calls.reject() }
            } else {
                RoundBtn(if (call.muted) Color.White else Color(0x55FFFFFF), if (call.muted) Icons.Default.MicOff else Icons.Default.Mic,
                    if (call.muted) Color.Black else Color.White) { Calls.setMuted(!call.muted) }
                RoundBtn(if (call.speaker) Color.White else Color(0x55FFFFFF), if (call.speaker) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    if (call.speaker) Color.Black else Color.White) { Calls.setSpeaker(!call.speaker) }
                if (call.video) RoundBtn(Color(0x55FFFFFF), Icons.Default.Cameraswitch) { Calls.switchCamera() }
                RoundBtn(Color(0xFFC62828), Icons.Default.CallEnd) { Calls.hangup() }
            }
        }
    }
}

@Composable
fun RoundBtn(bg: Color, icon: ImageVector, tint: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.size(64.dp).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint) }
}

@Composable
fun VideoView(track: VideoTrack?, modifier: Modifier, mirror: Boolean = false, overlay: Boolean = false) {
    var view by remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    AndroidView(
        factory = { c ->
            SurfaceViewRenderer(c).apply {
                init(Calls.egl.eglBaseContext, null)
                setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                setEnableHardwareScaler(true)
                setMirror(mirror)
                setZOrderMediaOverlay(overlay)
                view = this
            }
        },
        modifier = modifier,
        onRelease = { try { it.release() } catch (_: Exception) {} }
    )
    DisposableEffect(track, view) {
        val v = view
        val t = track
        if (v != null && t != null) {
            try { t.addSink(v) } catch (_: Exception) {}
        }
        onDispose {
            if (v != null && t != null) {
                try { t.removeSink(v) } catch (_: Exception) {}
            }
        }
    }
}
