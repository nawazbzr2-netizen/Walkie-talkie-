package com.phonelink.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.media.audiofx.AcousticEchoCanceler
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max

enum class Phase { IDLE, OUTGOING, INCOMING, CONNECTING, ACTIVE }

data class CallUi(
    val phase: Phase = Phase.IDLE,
    val peerKey: String = "",
    val peerName: String = "",
    val video: Boolean = false,
    val muted: Boolean = false,
    val speaker: Boolean = false,
    val startedAt: Long = 0,
    /** true = plain audio stream (used over Bluetooth), false = WebRTC */
    val raw: Boolean = false
)

/**
 * One call at a time.
 *  - Wi-Fi / hotspot / internet: WebRTC (audio + video). No time limit.
 *  - Bluetooth: a simple 16 kHz µ-law audio stream through the same Bluetooth link (audio only).
 */
object Calls {
    private const val TAG = "PhoneLinkCall"

    val ui = MutableStateFlow(CallUi())
    val remoteVideo = MutableStateFlow<VideoTrack?>(null)
    val localVideo = MutableStateFlow<VideoTrack?>(null)

    val egl: EglBase by lazy { EglBase.create() }
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: org.webrtc.AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var capturer: VideoCapturer? = null
    private var surfaceHelper: SurfaceTextureHelper? = null
    private val pendingIce = mutableListOf<IceCandidate>()
    private var remoteSet = false
    private var ringtone: MediaPlayer? = null
    private var connectingWatchdog: Boolean = false

    // =====================================================================
    //  Public API (safe to call from the UI thread)
    // =====================================================================

    fun start(peerKey: String, video: Boolean) {
        Hub.scope.launch { startInternal(peerKey, video) }
    }

    fun accept() { Hub.scope.launch { acceptInternal() } }
    fun reject() { Hub.scope.launch { hangupInternal() } }
    fun hangup() { Hub.scope.launch { hangupInternal() } }

    fun setMuted(m: Boolean) {
        ui.value = ui.value.copy(muted = m)
        audioTrack?.setEnabled(!m)
    }

    fun setSpeaker(on: Boolean) {
        ui.value = ui.value.copy(speaker = on)
        LinkService.instance?.setSpeaker(on)
    }

    fun switchCamera() {
        (capturer as? CameraVideoCapturer)?.switchCamera(null)
    }

    fun onPeerGone(peerKey: String) {
        if (ui.value.peerKey == peerKey && ui.value.phase != Phase.IDLE) {
            Hub.toast("Call ended: connection lost")
            Hub.scope.launch { cleanup() }
        }
    }

    // =====================================================================
    //  Signalling
    // =====================================================================

    private fun sig(a: String) = JSONObject().put("a", a)

    private fun send(peerKey: String, j: JSONObject) {
        Hub.peer(peerKey)?.trySend(FT.CALL, j.toString().toByteArray())
    }

    @Synchronized
    private fun startInternal(peerKey: String, video: Boolean) {
        if (ui.value.phase != Phase.IDLE) return
        val peer = Hub.peer(peerKey) ?: return
        val raw = peer.kind == Kind.BT
        val v = video && !raw
        ui.value = CallUi(Phase.OUTGOING, peerKey, peer.name, v, speaker = v, raw = raw)
        LinkService.instance?.callMode(true, v, v)
        send(peerKey, sig("invite").put("video", v))
        Hub.scope.launch {
            delay(45_000)
            if (ui.value.phase == Phase.OUTGOING && ui.value.peerKey == peerKey) {
                Hub.toast("No answer")
                hangupInternal()
            }
        }
    }

    @Synchronized
    private fun acceptInternal() {
        val s = ui.value
        if (s.phase != Phase.INCOMING) return
        stopRingtone()
        ui.value = s.copy(phase = Phase.CONNECTING, speaker = s.video)
        LinkService.instance?.callMode(true, s.video, s.video)
        startConnectingWatchdog(s.peerKey)
        try {
            if (s.raw) startRaw(s.peerKey) else setupRtc(s.peerKey, s.video)
            send(s.peerKey, sig("accept"))
        } catch (e: Exception) {
            Log.w(TAG, "accept failed: $e")
            Hub.toast("Could not start the call")
            hangupInternal()
        }
    }

    @Synchronized
    private fun hangupInternal() {
        val s = ui.value
        if (s.phase == Phase.IDLE) return
        send(s.peerKey, sig(if (s.phase == Phase.INCOMING) "reject" else "hangup"))
        cleanup()
    }

    @Synchronized
    fun onSignal(peer: Peer, j: JSONObject) {
        val s = ui.value
        when (j.optString("a")) {
            "invite" -> {
                if (s.phase != Phase.IDLE) {
                    peer.trySend(FT.CALL, sig("reject").toString().toByteArray())
                    return
                }
                val raw = peer.kind == Kind.BT
                ui.value = CallUi(Phase.INCOMING, peer.key, peer.name, j.optBoolean("video") && !raw, raw = raw)
                Hub.notifyUser("Incoming call", peer.name)
                startRingtone()
            }
            "accept" -> if (s.phase == Phase.OUTGOING && s.peerKey == peer.key) {
                stopRingtone()
                ui.value = s.copy(phase = Phase.CONNECTING)
                startConnectingWatchdog(s.peerKey)
                try {
                    if (s.raw) startRaw(s.peerKey) else {
                        setupRtc(s.peerKey, s.video)
                        makeOffer(s.peerKey)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "start failed: $e")
                    Hub.toast("Could not start the call")
                    hangupInternal()
                }
            }
            "reject", "hangup" -> if (s.peerKey == peer.key && s.phase != Phase.IDLE) {
                Hub.toast("Call ended")
                cleanup()
            }
            "offer" -> if (s.peerKey == peer.key) {
                val c = pc ?: return
                c.setRemoteDescription(object : SimpleSdp() {
                    override fun onSetSuccess() {
                        synchronized(Calls) { remoteSet = true; flushIce() }
                        c.createAnswer(object : SimpleSdp() {
                            override fun onCreateSuccess(d: SessionDescription?) {
                                if (d == null) return
                                c.setLocalDescription(SimpleSdp(), d)
                                send(peer.key, sig("answer").put("sdp", d.description))
                            }
                        }, MediaConstraints())
                    }
                }, SessionDescription(SessionDescription.Type.OFFER, j.getString("sdp")))
            }
            "answer" -> if (s.peerKey == peer.key) {
                val c = pc ?: return
                c.setRemoteDescription(object : SimpleSdp() {
                    override fun onSetSuccess() { synchronized(Calls) { remoteSet = true; flushIce() } }
                }, SessionDescription(SessionDescription.Type.ANSWER, j.getString("sdp")))
            }
            "ice" -> if (s.peerKey == peer.key) {
                val cand = IceCandidate(j.getString("m"), j.getInt("i"), j.getString("c"))
                if (remoteSet) pc?.addIceCandidate(cand) else pendingIce.add(cand)
            }
        }
    }

    private fun flushIce() {
        pendingIce.forEach { pc?.addIceCandidate(it) }
        pendingIce.clear()
    }

    // =====================================================================
    //  WebRTC (Wi-Fi, hotspot, internet)
    // =====================================================================

    open class SimpleSdp : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) { Log.w(TAG, "sdp create: $e") }
        override fun onSetFailure(e: String?) { Log.w(TAG, "sdp set: $e") }
    }

    private fun ensureFactory(): PeerConnectionFactory {
        factory?.let { return it }
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(Hub.ctx).createInitializationOptions()
        )
        val f = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
        factory = f
        return f
    }

    /** STUN is free (Google). For calls across mobile networks a TURN server can be added in Settings. */
    private fun iceServers(): List<PeerConnection.IceServer> {
        val l = mutableListOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        val url = Hub.prefs.getString("turn_url", "") ?: ""
        if (url.isNotBlank()) {
            l.add(
                PeerConnection.IceServer.builder(url)
                    .setUsername(Hub.prefs.getString("turn_user", "") ?: "")
                    .setPassword(Hub.prefs.getString("turn_pass", "") ?: "")
                    .createIceServer()
            )
        }
        return l
    }

    private fun setupRtc(peerKey: String, video: Boolean) {
        val f = ensureFactory()
        remoteSet = false
        pendingIce.clear()

        val cfg = PeerConnection.RTCConfiguration(iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        val conn = f.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                when (s) {
                    PeerConnection.IceConnectionState.CONNECTED,
                    PeerConnection.IceConnectionState.COMPLETED -> synchronized(Calls) {
                        val cur = ui.value
                        if (cur.phase == Phase.CONNECTING) {
                            ui.value = cur.copy(phase = Phase.ACTIVE, startedAt = System.currentTimeMillis())
                        }
                    }
                    PeerConnection.IceConnectionState.FAILED -> {
                        Hub.toast("Call failed: no route between the phones")
                        Hub.scope.launch { hangupInternal() }
                    }
                    else -> {}
                }
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate?) {
                if (c == null) return
                send(peerKey, sig("ice").put("m", c.sdpMid ?: "").put("i", c.sdpMLineIndex).put("c", c.sdp))
            }
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(d: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {
                val t = r?.track()
                if (t is VideoTrack) remoteVideo.value = t
            }
        }) ?: throw IllegalStateException("PeerConnection could not be created")
        pc = conn

        val src = f.createAudioSource(MediaConstraints())
        audioSource = src
        val at = f.createAudioTrack("a0", src)
        at.setEnabled(!ui.value.muted)
        audioTrack = at
        conn.addTrack(at, listOf("s0"))

        if (video) {
            val enumerator = Camera2Enumerator(Hub.ctx)
            val cam = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
                ?: enumerator.deviceNames.firstOrNull()
                ?: throw IllegalStateException("no camera")
            val cap = enumerator.createCapturer(cam, null)
            val helper = SurfaceTextureHelper.create("CaptureThread", egl.eglBaseContext)
            val vs = f.createVideoSource(false)
            cap.initialize(helper, Hub.ctx, vs.capturerObserver)
            cap.startCapture(640, 480, 24)
            capturer = cap
            surfaceHelper = helper
            videoSource = vs
            val vt = f.createVideoTrack("v0", vs)
            localVideo.value = vt
            conn.addTrack(vt, listOf("s0"))
        }
    }

    private fun makeOffer(peerKey: String) {
        val c = pc ?: return
        c.createOffer(object : SimpleSdp() {
            override fun onCreateSuccess(d: SessionDescription?) {
                if (d == null) return
                c.setLocalDescription(SimpleSdp(), d)
                send(peerKey, sig("offer").put("sdp", d.description))
            }
        }, MediaConstraints())
    }

    // =====================================================================
    //  Plain audio call (Bluetooth)
    // =====================================================================

    private const val RATE = 16000
    @Volatile private var rawRun = false
    private var rec: AudioRecord? = null
    private var play: AudioTrack? = null
    private val playQueue = LinkedBlockingQueue<ByteArray>(60)

    private fun startRaw(peerKey: String) {
        val minRec = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minRec, 4096) * 2
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("microphone not available")
        try {
            if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.setEnabled(true)
        } catch (_: Exception) {}

        val minPlay = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val p = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()
            )
            .setBufferSizeInBytes(max(minPlay, 4096) * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        rec = r
        play = p
        playQueue.clear()
        rawRun = true
        p.play()
        r.startRecording()
        ui.value = ui.value.copy(phase = Phase.ACTIVE, startedAt = System.currentTimeMillis())

        // microphone -> Bluetooth
        Thread {
            val pcm = ByteArray(640)               // 20 ms
            while (rawRun) {
                val n = r.read(pcm, 0, pcm.size)
                if (n <= 0) continue
                if (ui.value.muted) continue
                val out = ByteArray(n / 2)
                for (i in out.indices) {
                    val s = (pcm[2 * i].toInt() and 0xFF) or (pcm[2 * i + 1].toInt() shl 8)
                    out[i] = linear2ulaw(s.toShort().toInt())
                }
                val peer = Hub.peer(peerKey) ?: break
                if (!peer.trySend(FT.AUDIO, out)) break
            }
        }.apply { name = "bt-mic"; start() }

        // Bluetooth -> speaker
        Thread {
            while (rawRun) {
                val b = playQueue.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                val pcm = ByteArray(b.size * 2)
                for (i in b.indices) {
                    val s = ulaw2linear(b[i])
                    pcm[2 * i] = (s and 0xFF).toByte()
                    pcm[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
                }
                try { p.write(pcm, 0, pcm.size) } catch (_: Exception) { break }
            }
        }.apply { name = "bt-play"; start() }
    }

    fun onAudio(peer: Peer, data: ByteArray) {
        if (!rawRun || ui.value.peerKey != peer.key) return
        if (!playQueue.offer(data)) {          // keep latency low: drop the oldest chunk
            playQueue.poll()
            playQueue.offer(data)
        }
    }

    private fun stopRaw() {
        rawRun = false
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        try { play?.stop() } catch (_: Exception) {}
        try { play?.release() } catch (_: Exception) {}
        rec = null
        play = null
    }

    // G.711 µ-law
    private fun linear2ulaw(sample: Int): Byte {
        val bias = 0x84
        val clip = 32635
        var s = sample
        val sign = if (s < 0) { s = -s; 0x80 } else 0
        if (s > clip) s = clip
        s += bias
        var exp = 7
        var mask = 0x4000
        while (exp > 0 && (s and mask) == 0) { exp--; mask = mask shr 1 }
        val mant = (s shr (exp + 3)) and 0x0F
        return ((sign or (exp shl 4) or mant).inv() and 0xFF).toByte()
    }

    private fun ulaw2linear(b: Byte): Int {
        val u = (b.toInt() and 0xFF).inv() and 0xFF
        val t = (((u and 0x0F) shl 3) + 0x84) shl ((u and 0x70) shr 4)
        return if ((u and 0x80) != 0) 0x84 - t else t - 0x84
    }

    // =====================================================================
    //  Ringtone (phone default ring tone on incoming call)
    // =====================================================================

    private fun startRingtone() {
        stopRingtone()
        try {
            val uri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: return
            val mp = MediaPlayer()
            mp.setDataSource(Hub.ctx, uri)
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.isLooping = true
            mp.prepare()
            mp.start()
            ringtone = mp
        } catch (e: Exception) {
            Log.w(TAG, "ringtone failed: $e")
        }
    }

    private fun stopRingtone() {
        try { ringtone?.stop() } catch (_: Exception) {}
        try { ringtone?.release() } catch (_: Exception) {}
        ringtone = null
    }

    /** If WebRTC stays in CONNECTING too long, force hangup so the UI never sticks. */
    private fun startConnectingWatchdog(peerKey: String) {
        connectingWatchdog = true
        Hub.scope.launch {
            delay(30_000)
            if (connectingWatchdog && ui.value.phase == Phase.CONNECTING && ui.value.peerKey == peerKey) {
                Hub.toast("Call timed out – could not connect media")
                hangupInternal()
            }
        }
    }

    // =====================================================================
    //  Cleanup  (always resets UI so the app never sticks on a call screen)
    // =====================================================================

    @Synchronized
    private fun cleanup() {
        connectingWatchdog = false
        stopRingtone()
        stopRaw()
        remoteVideo.value = null
        localVideo.value = null
        try { pc?.close() } catch (_: Exception) {}
        try { pc?.dispose() } catch (_: Exception) {}
        pc = null
        try { capturer?.stopCapture() } catch (_: Exception) {}
        try { capturer?.dispose() } catch (_: Exception) {}
        capturer = null
        try { videoSource?.dispose() } catch (_: Exception) {}
        videoSource = null
        try { surfaceHelper?.dispose() } catch (_: Exception) {}
        surfaceHelper = null
        try { audioSource?.dispose() } catch (_: Exception) {}
        audioSource = null
        audioTrack = null
        pendingIce.clear()
        remoteSet = false
        LinkService.instance?.callMode(false, false, false)
        // Always reset UI last so Compose leaves CallScreen even if something above threw
        ui.value = CallUi()
    }
}
