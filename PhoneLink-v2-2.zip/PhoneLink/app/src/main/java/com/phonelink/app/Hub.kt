package com.phonelink.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

val BT_UUID: UUID = UUID.fromString("8f3d1c7e-5a1b-4a52-9c1d-0e6b7a2f4d10")

/**
 * Central brain of the app: owns every connection (Wi-Fi/hotspot, Bluetooth, internet),
 * routes frames to chat / file transfer / calls, and exposes state to the UI.
 */
object Hub {
    private const val TAG = "PhoneLink"

    lateinit var ctx: Context
    lateinit var myId: String
    private var attached = false
    private var started = false

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    /** True while the activity is on screen (used to decide about notifications). */
    @Volatile var uiVisible = false

    // ---- state for the UI ----
    val peers = MutableStateFlow<List<PeerInfo>>(emptyList())
    val discovered = MutableStateFlow<List<Discovered>>(emptyList())
    val btDevices = MutableStateFlow<List<BtDev>>(emptyList())
    val messages = MutableStateFlow<List<Msg>>(emptyList())
    val netStatus = MutableStateFlow("Off")
    val scanning = MutableStateFlow(false)
    val myIps = MutableStateFlow<List<String>>(emptyList())

    private val peerMap = ConcurrentHashMap<String, Peer>()
    private val netPeers = ConcurrentHashMap<String, Peer>()

    /** Addresses the user intentionally connected to – auto-reconnect tries these after a drop. */
    private val stickyWifi = ConcurrentHashMap.newKeySet<String>()
    private val stickyBt = ConcurrentHashMap.newKeySet<String>()
    private val stickyNet = ConcurrentHashMap.newKeySet<String>()
    @Volatile private var autoReconnect = true
    @Volatile private var reconnecting = false

    // ---- settings ----
    val prefs: SharedPreferences get() = ctx.getSharedPreferences("phonelink", Context.MODE_PRIVATE)
    var myName: String
        get() = prefs.getString("name", null) ?: Build.MODEL
        set(v) { prefs.edit().putString("name", v.trim().ifBlank { Build.MODEL }).apply() }
    var serverUrl: String
        get() = prefs.getString("server", "") ?: ""
        set(v) { prefs.edit().putString("server", v.trim()).apply() }

    @Synchronized
    fun attach(c: Context) {
        if (attached) return
        ctx = c.applicationContext
        attached = true
        var id = prefs.getString("id", null)
        if (id == null) {
            id = randomCode(10)
            prefs.edit().putString("id", id).putString("token", randomCode(24)).apply()
        }
        myId = id
    }

    private fun randomCode(n: Int): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = java.security.SecureRandom()
        return (1..n).map { alphabet[r.nextInt(alphabet.length)] }.joinToString("")
    }

    fun toast(msg: String) {
        mainHandler.post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
    }

    fun notifyUser(title: String, text: String) {
        if (!uiVisible) LinkService.instance?.notifyEvent(title, text)
    }

    // =====================================================================
    //  Start / stop
    // =====================================================================

    @Synchronized
    fun start() {
        if (started) return
        started = true
        startTcp()
        startBt()
        refreshBt()
        Discovery.start(ctx)
        refreshIps()
        if (serverUrl.isNotBlank()) connectServer()
    }

    @Synchronized
    fun stop() {
        started = false
        wantNet = false
        Calls.hangup()
        peerMap.values.toList().forEach { it.close() }
        netPeers.values.toList().forEach { it.close() }
        try { tcp?.close() } catch (_: Exception) {}
        tcp = null
        try { btServer?.close() } catch (_: Exception) {}
        btServer = null
        val old = ws
        ws = null
        old?.close(1000, null)
        Discovery.stop()
        netStatus.value = "Off"
    }

    fun peer(key: String): Peer? = peerMap[key]
    fun peerName(key: String): String = peerMap[key]?.name ?: key.substringAfter(':')

    // =====================================================================
    //  Wi-Fi / hotspot (TCP)
    // =====================================================================

    @Volatile private var tcp: ServerSocket? = null

    private fun startTcp() {
        if (tcp != null) return
        scope.launch {
            try {
                val ss = ServerSocket(PORT)
                tcp = ss
                while (true) {
                    val s = ss.accept()
                    s.tcpNoDelay = true
                    scope.launch {
                        runStream(Kind.WIFI, s.inetAddress.hostAddress ?: "?", s, s.getInputStream(), s.getOutputStream())
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "tcp server stopped: $e")
                tcp = null
            }
        }
    }

    fun connectWifi(host: String, port: Int = PORT) {
        val h = host.trim()
        if (h.isEmpty() || peerMap.containsKey("${Kind.WIFI.name}:$h")) return
        stickyWifi.add(h)
        scope.launch {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(h, port), 4000)
                s.tcpNoDelay = true
                runStream(Kind.WIFI, h, s, s.getInputStream(), s.getOutputStream())
            } catch (e: Exception) {
                toast("Could not connect to $h")
                scheduleReconnect()
            }
        }
    }

    /** Connects to every phone found by discovery / scan in one tap. */
    fun connectAll() {
        discovered.value.forEach { connectWifi(it.host, it.port) }
    }

    /** When this phone is connected to someone's hotspot, the hotspot owner is the gateway. */
    @Suppress("DEPRECATION")
    fun connectGateway() {
        val wm = ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo?.gateway ?: 0
        if (g == 0) { toast("No Wi-Fi gateway found"); return }
        connectWifi("${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}")
    }

    fun refreshIps() { myIps.value = localIps() }

    fun localIps(): List<String> = try {
        val prefixes = listOf("wlan", "ap", "swlan", "eth", "p2p", "softap")
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback && prefixes.any { p -> it.name.startsWith(p) } }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) {
        emptyList()
    }

    fun addDiscovered(d: Discovered) {
        if (d.host in localIps()) return
        discovered.update { list -> list.filter { it.host != d.host } + d }
    }

    fun removeDiscovered(name: String) {
        discovered.update { list -> list.filter { it.name != name } }
    }

    /** Looks at every address of the local /24 network(s) for phones running PhoneLink. */
    fun scanNetwork() {
        if (scanning.value) return
        scope.launch {
            scanning.value = true
            try {
                refreshIps()
                val own = localIps()
                val hosts = own.flatMap { ip ->
                    val prefix = ip.substringBeforeLast('.')
                    (1..254).map { "$prefix.$it" }
                }.filter { it !in own }
                val gate = Semaphore(40)
                coroutineScope {
                    for (h in hosts) launch { gate.withPermit { probe(h) } }
                }
            } finally {
                scanning.value = false
            }
        }
    }

    private fun probe(host: String) {
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, PORT), 400)
                s.soTimeout = 1500
                val (t, p) = Frames.read(DataInputStream(s.getInputStream()))
                if (t == FT.HELLO) {
                    val j = JSONObject(String(p, Charsets.UTF_8))
                    if (j.optString("id") != myId) {
                        addDiscovered(Discovered(j.optString("name", host), host, PORT))
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    // =====================================================================
    //  Bluetooth (RFCOMM)
    // =====================================================================

    @Volatile private var btServer: BluetoothServerSocket? = null

    fun hasBtPerm(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun btAdapter(): BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    @SuppressLint("MissingPermission")
    fun refreshBt() {
        if (!hasBtPerm()) return
        val a = btAdapter() ?: return
        btDevices.value = try {
            a.bondedDevices.map { BtDev(it.name ?: it.address, it.address) }.sortedBy { it.name.lowercase() }
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun startBt() {
        if (btServer != null || !hasBtPerm()) return
        val a = btAdapter() ?: return
        if (!a.isEnabled) return
        scope.launch {
            try {
                val ss = a.listenUsingRfcommWithServiceRecord("PhoneLink", BT_UUID)
                btServer = ss
                while (true) {
                    val s = ss.accept()
                    scope.launch {
                        runStream(Kind.BT, s.remoteDevice.address, s, s.inputStream, s.outputStream)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "bt server stopped: $e")
                btServer = null
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun connectBt(mac: String) {
        if (peerMap.containsKey("${Kind.BT.name}:$mac")) return
        val a = btAdapter() ?: return
        stickyBt.add(mac)
        scope.launch {
            try {
                a.cancelDiscovery()
                val s = a.getRemoteDevice(mac).createRfcommSocketToServiceRecord(BT_UUID)
                s.connect()
                runStream(Kind.BT, mac, s, s.inputStream, s.outputStream)
            } catch (e: Exception) {
                toast("Bluetooth connect failed (is PhoneLink open on the other phone?)")
                scheduleReconnect()
            }
        }
    }

    // =====================================================================
    //  Internet (signalling / relay server)
    // =====================================================================

    private val http by lazy { OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build() }
    @Volatile private var ws: WebSocket? = null
    @Volatile private var wantNet = false

    fun connectServer() {
        val url = serverUrl
        if (url.isBlank()) { netStatus.value = "No server address set"; return }
        val req = try { Request.Builder().url(url).build() } catch (e: Exception) {
            netStatus.value = "Bad server address"; return
        }
        wantNet = true
        netStatus.value = "Connecting…"
        val old = ws
        ws = null
        old?.cancel()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(
                    JSONObject().put("t", "register").put("id", myId)
                        .put("token", prefs.getString("token", "")).toString()
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val j = try { JSONObject(text) } catch (e: Exception) { return }
                when (j.optString("t")) {
                    "ok" -> netStatus.value = "Online"
                    "error" -> { netStatus.value = "Server: " + j.optString("msg"); wantNet = false }
                    "offline" -> {
                        val id = j.optString("id")
                        netPeers[id]?.let { if (!it.registered) it.close() }
                        toast("$id is offline")
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                try { onWsBinary(bytes.toByteArray()) } catch (e: Exception) { Log.w(TAG, "ws frame: $e") }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = wsDown(webSocket)
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) = wsDown(webSocket)
        })
    }

    fun disconnectServer() {
        wantNet = false
        val old = ws
        ws = null
        old?.close(1000, null)
        netPeers.values.toList().forEach { it.close() }
        netStatus.value = "Off"
    }

    private fun wsDown(socket: WebSocket) {
        if (ws !== socket) return
        ws = null
        netStatus.value = "Offline"
        netPeers.values.toList().forEach { it.close() }
        if (wantNet) scope.launch {
            delay(5000)
            if (wantNet && ws == null) connectServer()
        }
    }

    private fun sendWs(rid: String, frame: ByteArray) {
        val socket = ws ?: throw IOException("not connected to server")
        val idb = rid.toByteArray()
        val msg = ByteArray(1 + idb.size + frame.size)
        msg[0] = idb.size.toByte()
        System.arraycopy(idb, 0, msg, 1, idb.size)
        System.arraycopy(frame, 0, msg, 1 + idb.size, frame.size)
        // do not let a big file transfer overflow OkHttp's send queue
        while (socket.queueSize() > 1_500_000L) Thread.sleep(15)
        if (!socket.send(msg.toByteString())) throw IOException("send failed")
    }

    private fun onWsBinary(b: ByteArray) {
        if (b.isEmpty()) return
        val idLen = b[0].toInt() and 0xFF
        if (b.size < 1 + idLen + 5) return
        val rid = String(b, 1, idLen, Charsets.UTF_8)
        val (t, p) = Frames.decode(b, 1 + idLen) ?: return
        val peer = netPeers.getOrPut(rid) { newNetPeer(rid) }
        onFrame(peer, t, p)
    }

    private fun newNetPeer(rid: String): Peer {
        lateinit var p: Peer
        p = Peer(Kind.NET, rid, { frame -> sendWs(rid, frame) }, { unregister(p) })
        return p
    }

    /** Connect to a friend by the ID code shown on their Internet tab. */
    fun connectNet(rawId: String) {
        val rid = rawId.uppercase().filter { it.isLetterOrDigit() }
        if (rid.length < 6) { toast("Invalid ID"); return }
        if (rid == myId) { toast("That is your own ID"); return }
        if (ws == null) { toast("Connect to the server first"); return }
        stickyNet.add(rid)
        scope.launch {
            val p = netPeers.getOrPut(rid) { newNetPeer(rid) }
            p.trySend(FT.HELLO, helloJson(false))
        }
    }

    // =====================================================================
    //  Peer lifecycle + frame routing
    // =====================================================================

    private fun helloJson(reply: Boolean): ByteArray =
        JSONObject().put("id", myId).put("name", myName).put("re", reply).toString().toByteArray()

    private fun runStream(kind: Kind, address: String, closeable: Closeable, input: InputStream, output: OutputStream) {
        val lock = Any()
        val peer = Peer(
            kind, address,
            { bytes -> synchronized(lock) { output.write(bytes); output.flush() } },
            { try { closeable.close() } catch (_: Exception) {} }
        )
        peer.trySend(FT.HELLO, helloJson(false))
        try {
            val din = DataInputStream(BufferedInputStream(input, 32 * 1024))
            while (true) {
                val (t, p) = Frames.read(din)
                try { onFrame(peer, t, p) } catch (e: Exception) { Log.w(TAG, "frame $t: $e") }
            }
        } catch (_: Exception) {
        } finally {
            unregister(peer)
        }
    }

    private fun unregister(peer: Peer) {
        peer.close()
        if (peer.kind == Kind.NET) netPeers.remove(peer.address, peer)
        if (peerMap.remove(peer.key, peer)) {
            publishPeers()
            toast("Disconnected: ${peer.name}")
            Calls.onPeerGone(peer.key)
            cleanupTransfers(peer.key)
            // Unexpected drop → try auto-reconnect (user did not call disconnect())
            if (autoReconnect) scheduleReconnect()
        }
    }

    private fun publishPeers() {
        peers.value = peerMap.values
            .map { PeerInfo(it.key, it.name, it.kind, it.address) }
            .sortedBy { it.name.lowercase() }
    }

    /** User explicitly disconnects – remove from sticky list so we do NOT auto-reconnect. */
    fun disconnect(key: String) {
        val p = peerMap[key]
        if (p != null) {
            when (p.kind) {
                Kind.WIFI -> stickyWifi.remove(p.address)
                Kind.BT -> stickyBt.remove(p.address)
                Kind.NET -> stickyNet.remove(p.address)
            }
        }
        p?.close()
    }

    /**
     * After an unexpected drop, keep trying sticky Wi-Fi / Bluetooth / Internet peers
     * until they come back or the user explicitly disconnects them.
     */
    private fun scheduleReconnect() {
        if (!autoReconnect || reconnecting) return
        reconnecting = true
        scope.launch {
            try {
                var delayMs = 2_000L
                for (attempt in 1..20) {
                    delay(delayMs)
                    if (!started || !autoReconnect) break
                    var any = false
                    for (h in stickyWifi.toList()) {
                        if (!peerMap.containsKey("${Kind.WIFI.name}:$h")) {
                            any = true
                            try {
                                val s = Socket()
                                s.connect(InetSocketAddress(h, PORT), 3000)
                                s.tcpNoDelay = true
                                runStream(Kind.WIFI, h, s, s.getInputStream(), s.getOutputStream())
                            } catch (_: Exception) {}
                        }
                    }
                    for (mac in stickyBt.toList()) {
                        if (!peerMap.containsKey("${Kind.BT.name}:$mac")) {
                            any = true
                            try {
                                val a = btAdapter() ?: continue
                                a.cancelDiscovery()
                                val s = a.getRemoteDevice(mac).createRfcommSocketToServiceRecord(BT_UUID)
                                s.connect()
                                runStream(Kind.BT, mac, s, s.inputStream, s.outputStream)
                            } catch (_: Exception) {}
                        }
                    }
                    for (rid in stickyNet.toList()) {
                        if (!peerMap.containsKey("${Kind.NET.name}:$rid") && ws != null) {
                            any = true
                            connectNet(rid)
                        }
                    }
                    if (!any) break
                    delayMs = (delayMs * 1.5).toLong().coerceAtMost(30_000L)
                }
            } finally {
                reconnecting = false
            }
        }
    }

    private fun handleHello(peer: Peer, p: ByteArray) {
        val j = JSONObject(String(p, Charsets.UTF_8))
        val rid = j.optString("id")
        if (rid.isEmpty() || rid == myId) { peer.close(); return }
        peer.id = rid
        peer.name = j.optString("name").take(40).ifBlank { peer.address }
        if (peer.kind == Kind.NET && !j.optBoolean("re")) {
            peer.trySend(FT.HELLO, helloJson(true))
        }
        val old = peerMap[peer.key]
        if (old != null && old !== peer && !old.closed) { peer.close(); return }
        val first = !peer.registered
        peer.registered = true
        peerMap[peer.key] = peer
        publishPeers()
        if (first) toast("Connected: ${peer.name}")
    }

    private fun onFrame(peer: Peer, type: Int, p: ByteArray) {
        if (type == FT.HELLO) { handleHello(peer, p); return }
        if (!peer.registered) return
        when (type) {
            FT.CHAT -> {
                val text = String(p, Charsets.UTF_8)
                addMsg(Msg(nextId(), peer.key, false, "text", text = text, status = "done"))
                notifyUser(peer.name, text)
            }
            FT.FILE_META -> onFileMeta(peer, JSONObject(String(p, Charsets.UTF_8)))
            FT.FILE_ACCEPT -> {
                val j = JSONObject(String(p, Charsets.UTF_8))
                waiters.remove("${peer.key}/${j.getInt("fid")}")?.complete(j.optBoolean("ok"))
            }
            FT.FILE_CHUNK -> onFileChunk(peer, p)
            FT.FILE_END -> onFileEnd(peer, p)
            FT.CALL -> Calls.onSignal(peer, JSONObject(String(p, Charsets.UTF_8)))
            FT.AUDIO -> Calls.onAudio(peer, p)
        }
    }

    // =====================================================================
    //  Chat
    // =====================================================================

    private val msgCounter = AtomicLong(0)
    private fun nextId() = msgCounter.incrementAndGet()
    private fun addMsg(m: Msg) { messages.update { it + m } }

    private fun updateMsg(peerKey: String, fid: Int, mine: Boolean, f: (Msg) -> Msg) {
        messages.update { list ->
            list.map { if (it.peerKey == peerKey && it.fid == fid && it.mine == mine && it.kind != "text") f(it) else it }
        }
    }

    fun sendText(peerKey: String, text: String) {
        val peer = peerMap[peerKey] ?: return
        val t = text.trim()
        if (t.isEmpty()) return
        addMsg(Msg(nextId(), peerKey, true, "text", text = t, status = "done"))
        scope.launch { if (!peer.trySend(FT.CHAT, t.toByteArray())) toast("Message not sent") }
    }

    // =====================================================================
    //  File + voice-message transfer
    // =====================================================================

    private class Incoming(val out: OutputStream, val uri: Uri?, val pending: Boolean) {
        var got = 0L
        var lastUi = 0L
    }

    private class Offer(val name: String, val size: Long, val kind: String)

    private val fidCounter = AtomicInteger(0)
    private val waiters = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val offers = ConcurrentHashMap<String, Offer>()
    private val incoming = ConcurrentHashMap<String, Incoming>()

    private fun acceptJson(fid: Int, ok: Boolean) =
        JSONObject().put("fid", fid).put("ok", ok).toString().toByteArray()

    /** Sends any file (or a recorded voice message when [voice] is true). */
    fun sendFile(peerKey: String, uri: Uri, voice: Boolean = false) {
        val peer = peerMap[peerKey] ?: return
        scope.launch {
            val cr = ctx.contentResolver
            var name = uri.lastPathSegment ?: "file"
            var size = -1L
            try {
                cr.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val s = c.getColumnIndex(OpenableColumns.SIZE)
                        if (n >= 0 && !c.isNull(n)) name = c.getString(n)
                        if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
                    }
                }
            } catch (_: Exception) {}
            if (size < 0 && uri.scheme == "file") size = File(uri.path ?: "").length()

            val fid = fidCounter.incrementAndGet()
            val kind = if (voice) "voice" else "file"
            val wkey = "$peerKey/$fid"
            addMsg(Msg(nextId(), peerKey, true, kind, text = name, fid = fid, size = size, status = "waiting", uri = uri.toString()))

            val waiter = CompletableDeferred<Boolean>()
            waiters[wkey] = waiter
            val meta = JSONObject().put("fid", fid).put("name", name).put("size", size).put("kind", kind)
            if (!peer.trySend(FT.FILE_META, meta.toString().toByteArray())) {
                waiters.remove(wkey)
                updateMsg(peerKey, fid, true) { it.copy(status = "failed") }
                return@launch
            }
            val ok = withTimeoutOrNull(10 * 60_000L) { waiter.await() } ?: false
            waiters.remove(wkey)
            if (!ok) {
                updateMsg(peerKey, fid, true) { it.copy(status = "declined") }
                return@launch
            }

            updateMsg(peerKey, fid, true) { it.copy(status = "sending") }
            try {
                val chunk = if (peer.kind == Kind.BT) 4096 else 16384
                val buf = ByteArray(4 + chunk)
                ByteBuffer.wrap(buf).putInt(fid)
                var sent = 0L
                var lastUi = 0L
                (cr.openInputStream(uri) ?: throw IOException("cannot open file")).use { ins ->
                    while (true) {
                        val n = ins.read(buf, 4, chunk)
                        if (n <= 0) break
                        peer.send(FT.FILE_CHUNK, buf.copyOf(4 + n))
                        sent += n
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastUi > 250) {
                            lastUi = now
                            val s = sent
                            updateMsg(peerKey, fid, true) { it.copy(done = s) }
                        }
                    }
                }
                peer.send(FT.FILE_END, ByteBuffer.allocate(4).putInt(fid).array())
                val s = sent
                updateMsg(peerKey, fid, true) { it.copy(status = "done", done = s) }
            } catch (e: Exception) {
                updateMsg(peerKey, fid, true) { it.copy(status = "failed") }
            }
        }
    }

    private fun safeName(n: String) =
        n.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(100).ifBlank { "file" }

    private fun onFileMeta(peer: Peer, j: JSONObject) {
        val fid = j.getInt("fid")
        val name = safeName(j.optString("name", "file"))
        val size = j.optLong("size", -1)
        val kind = if (j.optString("kind") == "voice") "voice" else "file"
        offers["${peer.key}/$fid"] = Offer(name, size, kind)
        addMsg(Msg(nextId(), peer.key, false, kind, text = name, fid = fid, size = size, status = "offer"))
        if (kind == "voice" && size in 0..10_000_000) {
            respondFile(peer.key, fid, true)
            notifyUser(peer.name, "Voice message")
        } else {
            notifyUser(peer.name, "wants to send: $name")
        }
    }

    /** Called when the user taps Accept / Decline on a file offer (voice messages are accepted automatically). */
    fun respondFile(peerKey: String, fid: Int, accept: Boolean) {
        scope.launch {
            val peer = peerMap[peerKey] ?: return@launch
            val offer = offers.remove("$peerKey/$fid") ?: return@launch
            if (!accept) {
                updateMsg(peerKey, fid, false) { it.copy(status = "declined") }
                peer.trySend(FT.FILE_ACCEPT, acceptJson(fid, false))
                return@launch
            }
            try {
                val inc: Incoming
                val uriStr: String
                if (offer.kind == "voice") {
                    val dir = File(ctx.filesDir, "voice").apply { mkdirs() }
                    val f = File(dir, "${System.currentTimeMillis()}_${offer.name}")
                    inc = Incoming(FileOutputStream(f), null, false)
                    uriStr = Uri.fromFile(f).toString()
                } else {
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, offer.name)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PhoneLink")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        ?: throw IOException("cannot create file")
                    val os = ctx.contentResolver.openOutputStream(u) ?: throw IOException("cannot open file")
                    inc = Incoming(os, u, true)
                    uriStr = u.toString()
                }
                incoming["$peerKey/$fid"] = inc
                updateMsg(peerKey, fid, false) { it.copy(status = "receiving", uri = uriStr) }
                peer.trySend(FT.FILE_ACCEPT, acceptJson(fid, true))
            } catch (e: Exception) {
                updateMsg(peerKey, fid, false) { it.copy(status = "failed") }
                peer.trySend(FT.FILE_ACCEPT, acceptJson(fid, false))
            }
        }
    }

    private fun onFileChunk(peer: Peer, p: ByteArray) {
        if (p.size < 4) return
        val fid = ByteBuffer.wrap(p, 0, 4).int
        val inc = incoming["${peer.key}/$fid"] ?: return
        inc.out.write(p, 4, p.size - 4)
        inc.got += (p.size - 4)
        val now = SystemClock.elapsedRealtime()
        if (now - inc.lastUi > 250) {
            inc.lastUi = now
            val g = inc.got
            updateMsg(peer.key, fid, false) { it.copy(done = g) }
        }
    }

    private fun onFileEnd(peer: Peer, p: ByteArray) {
        if (p.size < 4) return
        val fid = ByteBuffer.wrap(p, 0, 4).int
        val inc = incoming.remove("${peer.key}/$fid") ?: return
        try { inc.out.close() } catch (_: Exception) {}
        if (inc.pending && inc.uri != null) {
            try {
                ctx.contentResolver.update(
                    inc.uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null
                )
            } catch (_: Exception) {}
        }
        val g = inc.got
        updateMsg(peer.key, fid, false) { it.copy(status = "done", done = g) }
    }

    private fun cleanupTransfers(peerKey: String) {
        val prefix = "$peerKey/"
        incoming.keys.filter { it.startsWith(prefix) }.forEach { k ->
            val inc = incoming.remove(k) ?: return@forEach
            try { inc.out.close() } catch (_: Exception) {}
            if (inc.pending && inc.uri != null) {
                try { ctx.contentResolver.delete(inc.uri, null, null) } catch (_: Exception) {}
            }
            val fid = k.substringAfterLast('/').toIntOrNull() ?: return@forEach
            updateMsg(peerKey, fid, false) { it.copy(status = "failed") }
        }
        waiters.keys.filter { it.startsWith(prefix) }.forEach { waiters.remove(it)?.complete(false) }
        offers.keys.filter { it.startsWith(prefix) }.forEach { offers.remove(it) }
    }
}
