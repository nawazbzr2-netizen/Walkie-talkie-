# PhoneLink

Phone-to-phone calls, video calls, chat, voice messages and file transfer — **without phone numbers** —
over Wi-Fi, mobile hotspot, Bluetooth or the internet.

| Feature | Wi-Fi / Hotspot | Bluetooth | Internet |
|---|---|---|---|
| Device list with IP address, tap to connect | ✅ (mDNS + subnet scan + manual IP) | ✅ paired phones | ✅ by ID code |
| Several phones at once | ✅ ("Connect all") | ✅ | ✅ |
| Voice call, no time limit | ✅ WebRTC | ✅ audio stream | ✅ WebRTC |
| Video call | ✅ | ❌ (Bluetooth is too slow) | ✅ |
| Text messages | ✅ | ✅ | ✅ |
| Voice messages (hold mic) | ✅ | ✅ | ✅ |
| Files of any type | ✅ fast | ✅ slow | ✅ via server (small files) |
| Incoming call ringtone | ✅ | ✅ | ✅ |
| Auto-reconnect after drop | ✅ | ✅ | ✅ |
| Call-stuck protection (30s timeout + full cleanup) | ✅ | ✅ | ✅ |

---

## GitHub سے APK بنائیں (سب سے آسان — Android Studio کی ضرورت نہیں)

1. https://github.com پر اکاؤنٹ بنائیں / لاگ اِن کریں
2. اوپر دائیں **+ → New repository** → نام `PhoneLink` → **Create repository**
3. **uploading an existing file** پر کلک کریں
4. اس زپ کو کھولیں اور **اندر کا سارا مواد** (app, gradle, gradlew, server, docs, .github …)
   ڈریگ اینڈ ڈراپ کریں → **Commit changes**
5. اوپر **Actions** ٹیب کھولیں → **Build APK** چلے گا (5–10 منٹ)
6. سبز ✓ آنے پر اس رن پر کلک کریں → نیچے **Artifacts → PhoneLink-debug-apk** ڈاؤنلوڈ کریں
7. زپ کھول کر `app-debug.apk` فون میں انسٹال کریں (Unknown sources اجازت دیں)

اگر Actions میں سرخ ✗ آئے تو رن کھول کر لاگ کا آخری حصہ کاپی کر کے بھیج دیں۔

> **ضروری:** `.github` فولڈر چھپا ہوتا ہے۔ اپلوڈ کے بعد ریپو میں `.github/workflows/android.yml` نظر آنا چاہیے۔
> نہ ہو تو **Add file → Create new file**، پاتھ لکھیں `.github/workflows/android.yml` اور ورک فلو کا مواد پیسٹ کر کے Commit کریں۔

---

## Android Studio سے

1. Android Studio (Ladybug یا نیا) انسٹال کریں
2. **File → Open** سے `PhoneLink` فولڈر کھولیں → Gradle Sync
3. فون USB سے لگائیں (Developer options + USB debugging) → **Run ▶**
4. APK: **Build → Build APK(s)** → `app/build/outputs/apk/debug/`

---

## پروجیکٹ ساخت

* `app/` – Android app (Kotlin, Jetpack Compose, WebRTC)
* `server/` – Node.js signalling server (صرف **Internet** ٹیب کے لیے)
* `docs/GUIDE_UR.md` – تفصیلی اردو گائیڈ
* `gradlew` + `gradle/wrapper/` – Gradle Wrapper (GitHub Actions خود استعمال کرتا ہے)
* `.github/workflows/android.yml` – ہر push پر APK بناتا ہے

> Permissions: mic / camera / Bluetooth صرف فیچر استعمال کرتے وقت مانگے جاتے ہیں۔
> یوزر پرمیشن نہ دے تو وہ فیچر بند رہتا ہے (Google policy compliant)۔
> دوسرے فون کا کیمرا/مائیک/سسٹم آڈیو **بغیر اس فون کی اجازت** ناممکن ہے۔
